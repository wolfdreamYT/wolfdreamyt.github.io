import os
import time
import shutil
import subprocess
from datetime import datetime
from threading import Lock
from functools import wraps
from urllib.parse import urlparse
from flask import (
    Flask, render_template, request, Response,
    send_from_directory, jsonify, abort, Response as FlaskResponse
)

# ----------------- CONFIG -----------------
app = Flask(__name__, template_folder="templates")

SEEDS_FILE = "seeds.txt"
WEBBOT_SCRIPT = "version3.py"
OUTPUT_FOLDER = "websites"
ZIP_FOLDER = "outputs"
os.makedirs(ZIP_FOLDER, exist_ok=True)

# Auth credentials
AUTH_USER = "demo"
AUTH_PASS = "S3curePass"

# Scan control
RUN_LOCK = Lock()
PROCESS_TIMEOUT_SEC = 60 * 30  # 30 minutes maximum session
MAX_ALLOWED_PAGES = 2000
# ------------------------------------------

# ----------------- AUTH SYSTEM -----------------
def authenticate():
    return FlaskResponse(
        "Authentication required",
        401,
        {"WWW-Authenticate": 'Basic realm="Login Required"'}
    )

def check_auth(username, password):
    return username == AUTH_USER and password == AUTH_PASS

def requires_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        auth = request.authorization
        if not auth or not check_auth(auth.username, auth.password):
            return authenticate()
        return f(*args, **kwargs)
    return decorated
# ------------------------------------------------


# ----------------- UTILITIES -----------------
def sanitize_seeds(text):
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    safe = []
    for l in lines:
        try:
            p = urlparse(l)
            if p.scheme in ("http", "https") and p.netloc:
                safe.append(l)
        except Exception:
            continue
    return safe


def make_zip_of_output():
    ts = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    zip_basename = f"webbot_output_{ts}"
    zip_path = os.path.join(ZIP_FOLDER, zip_basename)
    shutil.make_archive(zip_path, "zip", OUTPUT_FOLDER)
    return zip_basename + ".zip"
# ----------------------------------------------


# ----------------- ROUTES -----------------
@app.route("/")
def index():
    seeds = ""
    if os.path.exists(SEEDS_FILE):
        with open(SEEDS_FILE, "r", encoding="utf-8") as f:
            seeds = f.read()
    return render_template("index.html", seeds=seeds, max_pages=200)


@app.route("/save", methods=["POST"])
@requires_auth
def save():
    data = request.json or {}
    seeds = data.get("seeds", "")
    max_pages = data.get("max_pages", "")

    slist = sanitize_seeds(seeds)
    if not slist:
        return jsonify({"ok": False, "error": "No valid URLs provided"}), 400

    with open(SEEDS_FILE, "w", encoding="utf-8") as f:
        f.write("\n".join(slist) + "\n")

    try:
        if max_pages:
            n = int(max_pages)
            n = max(1, min(n, MAX_ALLOWED_PAGES))
            with open(".max_pages_override", "w") as f:
                f.write(str(n))
    except Exception:
        return jsonify({"ok": False, "error": "Invalid max_pages"}), 400

    return jsonify({"ok": True})


@app.route("/run", methods=["POST"])
@requires_auth
def run_scan():
    data = request.json or {}
    max_pages = data.get("max_pages", None)
    env = os.environ.copy()

    if max_pages:
        try:
            env["MAX_PAGES_OVERRIDE"] = str(int(max_pages))
        except Exception:
            pass
    elif os.path.exists(".max_pages_override"):
        with open(".max_pages_override", "r") as f:
            env["MAX_PAGES_OVERRIDE"] = f.read().strip()

    if not RUN_LOCK.acquire(blocking=False):
        return jsonify({"ok": False, "error": "Scan already running"}), 409

    def generate():
        try:
            proc = subprocess.Popen(
                ["python", WEBBOT_SCRIPT],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                env=env,
                text=True,
                bufsize=1,
                universal_newlines=True,
            )

            start = time.time()
            for line in iter(proc.stdout.readline, ""):
                elapsed = time.time() - start
                if elapsed > PROCESS_TIMEOUT_SEC:
                    proc.kill()
                    yield f"<br>Process killed after timeout ({PROCESS_TIMEOUT_SEC}s).<br>"
                    break
                safe = (
                    line.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                )
                yield safe.replace("\n", "<br>\n")

        except Exception as e:
            yield f"<br>ERROR STREAMING: {e}<br>"
        finally:
            try:
                proc.stdout.close()
            except Exception:
                pass
            try:
                proc.wait(timeout=5)
            except Exception:
                pass

            if os.path.exists(OUTPUT_FOLDER) and os.listdir(OUTPUT_FOLDER):
                try:
                    zipname = make_zip_of_output()
                    yield f"<br><br><!--DONE-->{zipname}<br>"
                except Exception as e:
                    yield f"<br><br><!--DONE-->ERROR_ZIP_CREATION: {e}<br>"
            else:
                yield "<br><br><!--DONE-->NO_OUTPUT<br>"

            RUN_LOCK.release()

    return Response(generate(), mimetype="text/html; charset=utf-8")


@app.route("/download/<path:zipname>")
@requires_auth
def download(zipname):
    if ".." in zipname or zipname.startswith("/") or "\\" in zipname:
        return abort(400)
    path = os.path.join(ZIP_FOLDER, zipname)
    if not os.path.exists(path):
        return abort(404)
    return send_from_directory(ZIP_FOLDER, zipname, as_attachment=True)
# --------------------------------------------


# ----------------- MAIN -----------------
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
# ----------------------------------------
